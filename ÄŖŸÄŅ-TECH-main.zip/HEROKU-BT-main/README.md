<a href="https://git.io/typing-hgm"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=100&pause=1000&color=purple&center=true&width=1500&height=200&lines=WELCOME+TO+ÄŖŸÄŅ-TECH🐆" alt="Typing HGM" /></a>

<p align="center">
  <img src="https://files.catbox.moe/ieywzr.jpg" width="300"/>
</p>



#### SETUP 

- <a href="https://github.com/eddy/ÄŖŸÄŅ-TECH🐆/fork"><img title="Tap Here Open Session Site" src="https://img.shields.io/badge/FORK THIS REPO-h?color=red&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>

________________________________

- <a href="https://aryan-csyv.onrender.com"><img title="SESSION SITE" src="https://img.shields.io/badge/SESSION SITE-h?color=green&style=for-the-badge&logo=msi" width="220" height="38.45"/></a></p>




#### DEPLOY TO HEROKU 
1. `If You Don't Have An Account On Heroku`

- <a align="center"><a href="https://signup.heroku.com">
 <img src="https://img.shields.io/badge/Create%20Account%20Now-purple?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

2. `If You Have a Heroku Account`

 - <a align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/Eddy/ÄŖŸÄŅ-TECH/tree/main"> <img src="https://img.shields.io/badge/DEPLOY%20NOW-blue?style=for-the-badge&logo=crome" width="220" height="38.45"/></a></p>

_______________________________
3.    `Deploy here to render`
    
[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/rahzayn/ÄŖŸÄŅ-TECH🐆)

_________________________________



*Thank you for choosing ARYAN-BT, Dont forget 🙃 to fork the repo🪡 and give star 🌟*
________________________________
#     CONTACT NUMBER


<a href="https://wa.me/+255637518095-INFO"><img title="CONTACT-Elon" src="https://img.shields.io/badge/CONTACT-aryan-tech?color=purple&style=for-the-badge&logo=audi" width="200" height="30.45"/></a></p>



<a href="https://git.io/typing-hgm"><img src="https://readme-typing-svg.demolab.com?font=Black+adam&size=100&pause=2000&color=purple&center=true&width=1000&height=200&lines=WELCOME+AGAIN" alt="Typing HGM" /></a>

